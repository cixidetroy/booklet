# Judge Booklet Generator

http://booklet.magicjudges.org/
